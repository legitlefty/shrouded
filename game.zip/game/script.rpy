# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define mystery = Character("???", who_color = "#807f7d")
define you = Character("You", who_color = "#ede4d5")
define me = Character("Me", who_color = "#ede4d5")
define d = Character("Daniel", who_color="#e6e377")
define a = Character("Anthony", who_color="#870f21")
define b = Character("Brixton", who_color="#0f8723")
define da = Character("David", who_color="#214186")
define an = Character("Andrew", who_color="#d7a007")
define w = Character("Wife", who_color="#c788c7")
define do = Character("Doctor", who_color="#d3d3d3")
define n = Character("Neighbor", who_color="#7d7bcc")

default subkarma = 0
default karma = 0

# The game starts here.

label start:
    play music "audio/cave.mp3"

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene black

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    # These display lines of dialogue.

    "..."

    "The coldness on your palms feels familiar."

    "{sc=3}It feels like...{/sc}"

    scene cave
    with dissolve

    show daniel_neutral

    mystery "You alright, little buddy?"

    "A friendly voice, as you feel a small nudge of a stick against your legs."

    you "Where..."

    hide daniel_neutral
    show daniel_frown_side

    mystery "You took quite the spill back there. You alright?"

    "You look up to see a nice old man, seeming to be in his late 70s, holding a wooden cane in his hand."

    menu:

        "What do you say?"

        "Who are you?":
            $ subkarma += 1
            jump who

        "How did I get here?":
            $ subkarma -= 1
            jump location
        
label who:
    hide daniel_frown_side
    show daniel_slightsmile

    d "Thanks for asking little buddy! My name is Daniel."


    jump start2

label location:

    hide daniel_frown_side
    show daniel_frown_side

    mystery "Does it matter?"

    "His tone seems to indicate that you shouldn't question him on the matter any further."

    hide daniel_frown_side
    show daniel_slightsmile

    d "Anyway, my name is Daniel."

    jump start2


label start2:
    "As you gather youself off of the floor, you find yourself in a dark cave, eeriely silent yet peaceful at the same time."

    "..."

    "It's cold."

    you "So, how do I leave?"

    hide daniel_slightsmile
    show daniel_frown
    
    d "Leave? Why?"

    you "I've got a wife to return to, you see?"

    hide daniel_frown
    show daniel_frown_side

    d "Me too."

    "He pulls out a photo wallet, containing photos of his wife. The photos are clearly dated."

    menu:

        "What do you say?"

        "How long have you been married?":
            $ subkarma -= 1
            jump deadwife

        "She's beautiful.":
            $ subkarma += 1
            jump awww

label deadwife:
    hide daniel_frown_side
    show daniel_smile

    d "About 50 years. She was-- she is a great woman."
    
    jump start3

label awww:
    hide daniel_frown_side
    show daniel_smile
    d "Thank you! She was-- she is the most beautiful woman I've ever seen."

    jump start3

label start3:
    "Was?"

    you "Why don't you leave? I'm sure she's waiting for you."

    hide daniel_smile
    show daniel_frown_side

    d "Hmm, maybe."

    "His past-tense remark of his wife still lingers at the back of your mind."

    "Dated photos, past-tense, unwillingness to leave..."

    "She's dead. It's the only explanation."

    menu:

        "What do you say?"

        "...":
            $ subkarma -= 1
            jump silence

        "Why don't we leave together?":
            $ subkarma += 1
            jump start4

label silence:
    d "Come. Let's sit by the fire together."

    you "Of course."

    jump start4

label start4:
    if subkarma >= 0:
        hide daniel_frown_side
        show daniel_slightsmile
        "He looks at you, and smiles slightly."
        $ karma += 1
    else:
        hide daniel_frown_side
        show daniel_frown
        "He looks at you, and frowns slightly."
        $ karma -= 1

    scene white
    with dissolve
    
    "The world seems to slip away from you."

    "Before you realize it..."

    scene street
    with dissolve

    stop music
    play music "audio/street.mp3"

    $ subkarma = 0

    "You hear the sound of cars pass by, along with the hustle and bustle of cityfolk."

    "It doesn't take but a few moments before you the stench hits you."

    "The distinct smell... {sc=3}of blood...{/sc}"

    mystery "Hey... a little help?"

    "A man sits slumped against a nearby dumpster, bruised and bloodied."
    show anthony_neutral_side


    menu:

        "What do you say?"

        "What happened?":
            $ subkarma -= 1
            jump happened

        "*Lend him your hand*":
            $ subkarma += 1
            jump start5

        "No.":
            $ subkarma -= 2
            jump no

label happened:

    hide anthony_neutral_side
    show anthony_frown

    mystery "Isn't it obvious? I got jumped by a couple of half-pints."

    "You help him up."

    jump start5

label no:

    hide anthony_neutral_side
    show anthony_frown
    
    mystery "What, looking to get beat up?"

    "..."

    mystery "Har, I'm only kidding. Wipe that expression off your face."

    "He manages to get up, with some effort."

    jump start5

label start5:
    you "Who are you?"

    hide anthony_frown
    show anthony_whistle

    a "Name's Anthony, thanks for asking."

    "..."

    hide anthony_whistle
    show anthony_frown_side

    a "It's like you're asking why I got jumped."

    hide anthony_frown_side
    show anthony_neutral

    a "Stupid question, really."

    menu:

        "What do you say?"

        "You gonna tell me or not?":
            $ subkarma -= 1
            jump tell

        "What now?":
            $ subkarma += 1
            jump start6

label tell:
    hide anthony_neutral
    show anthony_frown_side

    a "Hah, no."

    hide anthony_frown
    show anthony_neutral

    you "So, what now?"

    jump start6

label start6:
    hide anthony_neutral
    show anthony_whistle

    a "Hmm, are you interested in fighting?"

    you "Isn't it a bit unfair? You're all..."

    hide anthony_whistle
    show anthony_whistle_side

    a "No, no, not me. Yet. I have a club. Every week we go and, well, fight. You interested?"
    
    menu:

        "What do you say?"
        
        "Sounds fun.":
            $ subkarma -= 1
            jump start7

        "Not really my thing.":
            $ subkarma += 1
            jump start7

label start7:
    if subkarma >= 0:
        hide anthony_neutral
        show anthony_whistle
        "He looks at you, and smirks."
        $ karma += 1
    else:
        hide anthony_neutral
        show anthony_frown
        "He looks at you with distaste."
        $ karma -= 1

    stop music

    scene white
    with dissolve
    
    "The world seems to slip away from you."

    scene black

    "The tires hum against the road."

    "The dim glow of the passing light poles."

    "A voice."

    "Who?"

    scene white

    "Before you realize it..."

    $ subkarma = 0

    scene city
    with dissolve

    play music "audio/city.mp3"

    mystery "Hey!"

    show brixton_neutral_open

    "Before you can come to your senses, a man in a fine suit shouts into the crowd."

    mystery "Buy them before they're gone! Come on!"

    hide brixton_neutral_open
    show brixton_neutral

    "A rapid excitement fills his voice."

    hide brixton_neutral
    show brixton_neutral_open

    mystery "Buy now!"

    mystery "{size=+10}Buy now!{/size}"

    mystery "{size=+30}BUY NOW!{/size}"

    menu:

        "What do you say?"
        
        "What are you selling?":
            $ subkarma += 1
            jump buying

        "Not interested.":
            $ subkarma -= 1
            jump notbuying
            
label buying:

    hide brixton_neutral_open
    show brixton_fear

    mystery "Wait, you're actually interested?"

    hide brixton_fear
    show brixton_fear_open

    "The desperation in his voice swells."

    mystery "Thank you!"

    you "You haven't even told me what you're selling yet."

    hide brixton_fear_open
    show brixton_neutral

    mystery "Oh, right..."

    jump start8

label notbuying:
    "The desperation in his voice swells."

    hide brixton_neutral_open
    show brixton_fear_open

    mystery "Wait! {size=+10}Wait!{/size} You have to hear me out!"

    hide brixton_fear_open
    show brixton_neutral

    jump start8

label start8:
    mystery "I'm selling lottery tickets!"

    you "Those scams?"

    hide brixton_neutral
    show brixton_neutral_open

    mystery "But what if you win?"

    you "You won't."

    mystery "You might!"

    "Your curiosity gets the better of you."

    you "Why are you so desperate to sell?"

    hide brixton_neutral_open
    show brixton_neutral

    mystery "I'm enthusiastic about my job, that's all!"

    "You shoot him an incredulous look."

    mystery "..."

    hide brixton_neutral
    show brixton_focused

    mystery "Fine. I decided to let my son drive himself to work, and he got in a car accident."
    
    mystery "His medical bills are too high for me to earn by salary, so I now earn by commissions."

    hide brixton_focused
    show brixton_focused_open

    mystery "If only I had driven, or if he was a little more careful, or..."

    menu:

        "What do you say?"
        
        "You're right, a small change would've changed everything.":
            $ subkarma -= 1
            jump call

        "Just focus on selling lottery tickets now, nothing you can change.":
            $ subkarma += 1
            jump broke

label call:
    mystery "Yeah."
    hide brixton_focused_open
    show brixton_focused
    jump start9

label broke:
    mystery "I suppose that's true."
    hide brixton_focused_open
    show brixton_focused
    jump start9

    

label start9:
    "He hands you his business card with his name: Brixton"

    hide brixton_focused
    show brixton_neutral

    b "Give me a call!"

    if subkarma >= 0:
        "He turns around and waves at you, with a small grin on his face."

        hide brixton_neutral
        show brixton_neutral_open

        $ karma += 1
    else:
        "He runs off to the next crowd of people."

        hide brixton_neutral
        show brixton_focused

        $ karma -= 1

    stop music

    scene white
    with dissolve
    
    "The world seems to slip away from you."

    scene black

    "A woman."

    "The voice of a woman."

    "Your wife."

    "She's... {sc=5}screaming...{/sc}."

    scene white

    "Before you realize it..."

    scene graveyard
    with dissolve

    show david_neutral

    play music "audio/graveyard.mp3"
    
    "..."

    "A soldier. His dogtags read David."

    "Graves spanning into the horizon."

    "Rain pours down on the concrete slabs."

    da "Tell me. What do you see?"

    menu:

        "What do you say?"
        
        "Graves.":
            $ subkarma += 1
            jump graves

        "Lives.":
            $ subkarma -= 1
            jump lives    

label graves:
    da "..."

    hide david_neutral
    show david_smile

    da "Yes, maybe you're right."

    hide david_smile
    show david_neutral

    jump start10

label lives:
    da "..."

    da "I see."

    jump start10

label start10:
    da "Tell me, have you ever killed someone?"

    you "No."

    da "Say, how do you think it would feel?"
    menu:

        "What do you say?"
        
        "Bad.":
            $ subkarma -= 1
            jump bad

        "Unforgettable.":
            $ subkarma += 1
            jump unforgettable   

label bad:
    da "..."
    jump start11

label unforgettable:
    da "That is..."

    hide david_neutral
    show david_smile

    da "an accurate assessment."

    hide david_smile
    show david_neutral

    jump start11


label start11:
    "There is nothing more to say."

    if subkarma >= 0:
        "Yet somehow, that is enough."
        $ karma += 1
    else:
        $ karma -= 1

    stop music

    scene white
    with dissolve
    
    "The world seems to slip away from you."

    "Before you realize it..."

    if karma == -4:
        jump badend
    elif karma == 4:
        jump goodend
    else:
        jump neutralend

label badend:
    scene black
    "It's the end."
    "You passed away without ever knowing why."
    centered "BAD ENDING"

    jump end

label neutralend:
    play music "audio/white.mp3"
    "Wait."

    "Something's different."

    show abraham_frown

    "You see an old man in a hospital gown in the distance."

    "He looks at you, and slightly frowns."

    scene black
    with dissolve

    stop music

    "..."

    scene hospital
    with dissolve

    play music "audio/beep.mp3"

    do "The patient is awake."

    you "...what..."

    do "You were involved in a car accident, and put in a coma."

    you "Oh..."

    "You try to sit up, but can't seem to find the leverage."

    do "Your legs were amputated as a result of the accident."

    you "My legs..?"

    do "Yes. You will remain in the hospital for about three months before being returned home, assuming everything goes well."

    "You think back to your dream."

    you "Where is my wife?"

    do "Please refer to the note on the side table."

    "You look over to see a neatly written note next to you."

    scene letter

    ""

    scene black
    with fade

    stop music

    centered "NEUTRAL ENDING"

    jump end

label goodend:
    play music "audio/white.mp3"

    "Wait."

    "Something's different."

    show abraham_smile

    "You see an older man in a hospital gown in the distance."

    "As you approach, he waves you over."

    "Hello."

    you "Huh?"

    "It's me. Andrew."

    you "So that voice..."

    an "Yes. It has been me talking to you."

    you "Where are we?"

    an "A more accurate question would be asking where you are."

    you "Huh?"

    hide abraham_smile
    show abraham_frown

    an "You have been in a coma for quite some time."

    hide abraham_frown
    show abraham_smile

    you "So everything that just happened..."

    an "Yes. You have been asleep in the hospital."

    you "Why?"
    
    hide abraham_smile
    show abraham_frown

    an "You got into a car accident."

    hide abraham_frown
    show abraham_smile

    you "..."

    you "Do I have a wife?"

    an "Yes."

    you "Was she in the car?"

    an "Yes."

    you "Is she okay?"

    an "See for yourself."

    an "It's time to wake up..."

    an "Andrew."
    
    scene black
    with dissolve

    stop music

    "..."

    scene hospital
    with dissolve

    play music "audio/beep.mp3"

    me "Where…"
    
    show wife_happy

    w "Andrew? Andrew!"

    me "Melissa..."

    hide wife_happy
    show wife_happy_side

    w "You were out for so long, I thought that you-"

    me "It's okay, I'm here."

    hide wife_happy_side
    show wife_cry

    "Melissa wipes her tears and comes closer."

    hide wife_cry
    show wife_slightlyhappy

    w "You caused me quite the scare. I didn't know if you were ever going to wake up."

    me "How... long was I out?"

    w "Two months."

    me "Two months? So that means you..."

    hide wife_slightlyhappy
    show wife_slightlyhappy_side

    "She looks away with a familiar expression."

    "I attempt to get her back with a shove, but when I try to move..."

    me "..."

    me "Oh."

    w "The doctor had to amputate them. I'm so sorry."

    hide wife_slightlyhappy_side
    show wife_neutral_side

    "I looked down. Everything below my thighs were gone."

    w "You'll be discharged from the hospital hopefully soon, and when that happens..."

    hide wife_neutral_side
    show wife_slightlyhappy

    w "Well, we can go to that same burger joint."

    "I chuckle." 

    "More importantly..."

    me "I'm so sorry."

    hide wife_slightlyhappy
    show wife_neutral

    "She sighs."

    w "I've already forgiven you Andrew."

    me "No, not just the crash, but for everything."

    "She pauses."

    w "Andrew, please don't apologize for things that you can't control."

    hide wife_neutral
    show wife_neutral_side

    w "Yes, the accident was partially your fault, but being in a coma for two months is..."

    me "Well, you always said I was a stubborn one."

    hide wife_neutral_side
    show wife_slightlyhappy

    "Melissa slyly chuckles.."

    hide wife_slightlyhappy
    show wife_happy

    w "Andrew, don't ever scare me like that again. Okay?"

    me "I promise."

    scene black
    with fade
    
    stop music

    centered "GOOD ENDING"

    jump end

label end:
    ""
    scene white
    with dissolve

    show neighbor

    play sound neighbor

    n "hello, im your neighbor"

    n "and this is the credits screen"

    n "i thought that i'd like to explain how this singular sprite of hello neighbor gave me a 30 minute problem"

    n "for some reason, this was the ONLY sprite that worked with my game"

    n "every other sprite would not properly import"

    n "except for this SINGULAR picture of hello neighbor"

    n "anyway the fix was lowkey boring but it took like 30 minutes so"

    n "that's fun"

    n "..."

    n "i never really got to use them but i found a lot of funky features i can use here"

    n "watch this"

    show neighbor at right
    with move

    show neighbor at top
    with move

    show neighbor at left
    with move

    show neighbor at top
    with move

    show neighbor at right
    with move

    show neighbor at top
    with move

    show neighbor at right
    with move

    show neighbor at top
    with move

    show neighbor at left
    with move

    show neighbor at top
    with move

    show neighbor at center
    with move

    n "crazy stuff"

    n "i also installed this plugin i used like twice but it's got all kinds of fun stuff"

    n "check it out"


    n "{bt=3} someone help the text is breathing {/bt}"

    n "{move}{b} the text is running from the mouse brah {/move}"

    n "the other ones literally blow up my computer (see spencers video)"

    n "anyway game was created by team okie dokie"

    n "spencer did the backgrounds and lots of the story outlining"

    n "angelo did the sprite artwork and wrote a few segments of the story"

    n "and kingston did the \"coding\" in ren'py and story writing"

    n "well thanks for playing"

    n "i totally didn't just stall to hit line 1000"